#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# setup.sh — install, verify, and package the Stealth Calculator Chat app.
#
#   ./setup.sh            install deps + typecheck + zip
#   ./setup.sh --no-install   skip npm install (fast, for an already-set-up tree)
#   ./setup.sh --assets       also regenerate icons/splash (needs python3+PIL)
#
# Output: stealth-calculator-chat.zip in the current directory.
# ---------------------------------------------------------------------------
set -euo pipefail

APP_NAME="stealth-calculator-chat"
SKIP_INSTALL=0
DO_ASSETS=0

for arg in "$@"; do
  case "$arg" in
    --no-install) SKIP_INSTALL=1 ;;
    --assets) DO_ASSETS=1 ;;
    -h|--help) sed -n '2,12p' "$0"; exit 0 ;;
    *) echo "Unknown option: $arg" >&2; exit 1 ;;
  esac
done

say() { printf '\033[1;32m▸ %s\033[0m\n' "$1"; }
warn() { printf '\033[1;33m! %s\033[0m\n' "$1"; }
die() { printf '\033[1;31m✗ %s\033[0m\n' "$1" >&2; exit 1; }

# --- 0. sanity -------------------------------------------------------------
command -v node >/dev/null || die "Node.js 18+ is required."
command -v npm  >/dev/null || die "npm is required."
NODE_MAJOR="$(node -p 'process.versions.node.split(".")[0]')"
[ "$NODE_MAJOR" -ge 18 ] || die "Node 18+ required (found $(node -v))."

[ -f app.json ] || die "Run this from the project root (app.json not found)."

# --- 1. dependencies -------------------------------------------------------
if [ "$SKIP_INSTALL" -eq 0 ]; then
  say "Installing dependencies (npm ci if a lockfile exists)…"
  if [ -f package-lock.json ]; then
    npm ci --no-audit --no-fund || npm install --no-audit --no-fund
  else
    npm install --no-audit --no-fund
  fi
else
  warn "Skipping dependency install."
fi

# --- 2. optional asset regeneration ---------------------------------------
if [ "$DO_ASSETS" -eq 1 ]; then
  if python3 -c 'import PIL' 2>/dev/null; then
    say "Regenerating icons and splash…"
    python3 scripts/generate-assets.py
  else
    warn "Pillow not installed (pip install Pillow) — keeping shipped assets."
  fi
fi

# --- 3. typecheck ----------------------------------------------------------
say "Type-checking…"
npx tsc --noEmit

# --- 4. config sanity ------------------------------------------------------
say "Validating Expo config…"
npx expo config --type prebuild >/dev/null

if [ ! -f google-services.json ]; then
  warn "google-services.json not found — the app will run in demo mode."
  warn "See FIREBASE_SETUP.md before you build."
fi

# --- 5. zip ----------------------------------------------------------------
ZIP_OUT="${APP_NAME}.zip"
say "Packaging ${ZIP_OUT}…"
rm -f "$ZIP_OUT"

zip -r -q "$ZIP_OUT" . \
  -x 'node_modules/*' \
  -x '.git/*' \
  -x '.expo/*' \
  -x 'android/*' \
  -x 'ios/*' \
  -x 'dist/*' \
  -x '*/.DS_Store' \
  -x '.DS_Store' \
  -x "$ZIP_OUT" \
  -x 'google-services.json' \
  -x 'GoogleService-Info.plist' \
  -x '.env' -x '.env.*'

say "Done → ${ZIP_OUT}  ($(du -h "$ZIP_OUT" | cut -f1))"
echo
echo "Next:"
echo "  1. unzip ${ZIP_OUT} && cd ${APP_NAME} && npm install"
echo "  2. drop google-services.json in the repo root  (FIREBASE_SETUP.md)"
echo "  3. eas build --profile preview --platform android"
