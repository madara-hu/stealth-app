#!/usr/bin/env python3
"""
generate-assets.py — regenerates every icon/splash asset from geometry.

Why procedural? The app icon must look razor-sharp at 48px and 1024px, and it
must ship with a *clean* transparent adaptive-foreground (the Android safe
zone is only the middle 66%). Raster/AI art blurs and leaves glow discs, which
Android then crops badly. These are drawn at 3x and downsampled — no assets
needed beyond Pillow.

Usage:  python3 scripts/generate-assets.py
"""
from PIL import Image, ImageDraw, ImageFilter

INK = (10, 10, 10)
PANEL = (20, 20, 23)
KEY = (58, 58, 64)
KEY_EDGE = (74, 74, 82)
EMERALD = (0, 224, 122)
SS = 3  # supersample factor


def rounded(draw, box, radius, fill=None, outline=None, width=1):
    draw.rounded_rectangle(box, radius=radius, fill=fill, outline=outline, width=width)


def glyph(size, scale=1.0, glow=False):
    """The calculator glyph on a transparent canvas of `size` px.

    All geometry below is authored against a 1024px reference canvas and then
    multiplied by `k`, so the mark keeps identical proportions at every size.
    """
    S = size * SS
    k = S / 1024.0 * scale
    img = Image.new("RGBA", (S, S), (0, 0, 0, 0))

    # Body geometry: 520x660 reference box, centred.
    bw, bh = int(520 * k), int(660 * k)
    x0 = (S - bw) // 2
    y0 = (S - bh) // 2
    x1, y1 = x0 + bw, y0 + bh
    r = int(96 * k)
    stroke = max(2, int(7 * k))

    if glow:
        halo = Image.new("RGBA", (S, S), (0, 0, 0, 0))
        hd = ImageDraw.Draw(halo)
        rounded(hd, (x0, y0, x1, y1), r, outline=EMERALD + (170,), width=stroke * 3)
        halo = halo.filter(ImageFilter.GaussianBlur(S * 0.014))
        img.alpha_composite(halo)

    d = ImageDraw.Draw(img)
    # body shell
    rounded(d, (x0, y0, x1, y1), r, fill=PANEL + (255,), outline=EMERALD + (235,), width=stroke)

    # display bar
    pad = int(60 * k)
    disp_h = int(120 * k)
    disp_top = y0 + pad
    rounded(
        d,
        (x0 + pad, disp_top, x1 - pad, disp_top + disp_h),
        int(26 * k),
        fill=(8, 26, 18, 255),
        outline=EMERALD + (255,),
        width=max(2, int(6 * k)),
    )

    # 3x3 key grid
    cols, rows = 3, 3
    grid_top = disp_top + disp_h + int(52 * k)
    grid_bottom = y1 - pad
    gap = int(26 * k)
    avail_w = (x1 - pad) - (x0 + pad)
    kw = (avail_w - gap * (cols - 1)) // cols
    kh = (grid_bottom - grid_top - gap * (rows - 1)) // rows

    for row in range(rows):
        for col in range(cols):
            kx = x0 + pad + col * (kw + gap)
            ky = grid_top + row * (kh + gap)
            is_accent = row == rows - 1 and col == cols - 1
            fill = EMERALD + (255,) if is_accent else KEY + (255,)
            edge = EMERALD + (255,) if is_accent else KEY_EDGE + (255,)
            rounded(
                d,
                (kx, ky, kx + kw, ky + kh),
                int(30 * k),
                fill=fill,
                outline=edge,
                width=max(1, int(2 * k)),
            )

    return img.resize((size, size), Image.LANCZOS)


def radial_glow(size, color=EMERALD, strength=0.30, core=0.42):
    """Tight emerald bloom for the launcher icon background (no visible disc)."""
    grad = Image.radial_gradient("L").resize((size, size), Image.LANCZOS)
    limit = int(255 * core)

    def curve(v):
        if v >= limit:
            return 0
        t = 1.0 - (v / limit)
        return int((t ** 2.4) * 255 * strength)

    alpha = grad.point(curve)
    layer = Image.new("RGBA", (size, size), color + (0,))
    layer.putalpha(alpha)
    return layer.filter(ImageFilter.GaussianBlur(size * 0.01))


def main():
    # 1) Launcher icon — full bleed, ink background + bloom + glyph
    icon = Image.new("RGBA", (1024, 1024), INK + (255,))
    icon.alpha_composite(radial_glow(1024))
    g = glyph(1024, scale=0.92, glow=True)
    icon.alpha_composite(g)
    icon.convert("RGB").save("assets/icon.png", optimize=True)

    # 2) Adaptive foreground — transparent, glyph inside the 66% safe zone
    fg = Image.new("RGBA", (1024, 1024), (0, 0, 0, 0))
    fg.alpha_composite(glyph(1024, scale=0.62))
    fg.save("assets/adaptive-icon.png", optimize=True)

    # 3) Splash — transparent mark; the ink background comes from app.json
    sp = Image.new("RGBA", (1280, 1280), (0, 0, 0, 0))
    mark = glyph(1280, scale=0.52, glow=True)
    sp.alpha_composite(mark)
    sp.save("assets/splash.png", optimize=True)

    # 4) Favicon
    glyph(64, scale=0.9).save("assets/favicon.png", optimize=True)

    print("assets written: icon.png, adaptive-icon.png, splash.png, favicon.png")


if __name__ == "__main__":
    main()
