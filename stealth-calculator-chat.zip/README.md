# Stealth Calculator Chat

A premium dark calculator that hides a WhatsApp-style private vault behind a
secret keypad sequence.

```
7 · 4 · + · 8 · 8 · =      →  the vault opens
```

Outer shell: an iOS-grade calculator (`#0A0A0A`, pill keys, emerald accents).
Hidden side: a real-time chat with **Navneet, Shreya, Navya and W.O.N.S**,
backed by Firebase Auth + Firestore. Tap **Lock** anywhere to snap straight
back to the calculator with `0` on the display.

---

## 1. Stack

| Piece | Version |
|---|---|
| Expo SDK | **52** (RN 0.76.9, React 18.3.1) |
| Language | TypeScript (strict) |
| Backend | `@react-native-firebase/app` · `auth` · `firestore` v21 |
| UI | `StyleSheet` only — no Tailwind/NativeWind, no icon fonts |
| Icons | `react-native-svg` (hand-drawn paths, zero asset linking) |
| Navigation | **none** — a plain state machine in `App.tsx` (see §6) |

---

## 2. Install and run

```bash
npm install

# Android
npx expo run:android        # or: eas build --profile development --platform android

# Type-check
npm run typecheck
```

> The app runs **without** Firebase credentials in "demo mode": the vault is
> fully clickable and messages are kept in memory, so you can review the UI
> before you touch the Firebase console.

---

## 3. Add your Firebase project (`google-services.json`)

1. Firebase console → **Add project**.
2. **Add app → Android**.
   * Android package name **must** match `app.json → expo.android.package`.
     It ships as `com.yourcompany.calculator` — change it to your own, and change
     it in the console to the same value.
3. Download `google-services.json` and drop it in the **repo root**, next to
   `package.json` (not in `android/`, which is generated):

```
stealth-calculator-chat/
├── google-services.json   ← here
├── app.json
└── package.json
```

4. **Auth** → Sign-in method → enable **Anonymous**.
5. **Firestore Database** → Create database → start in *production mode*.
6. Paste these rules (Settings → Rules). They keep the vault private to signed-in
   users while still letting the four contacts talk in real time:

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /rooms/{roomId} {
      allow read, write: if request.auth != null;

      match /messages/{messageId} {
        allow read: if request.auth != null;
        allow create: if request.auth != null
                      && request.resource.data.text is string
                      && request.resource.data.text.size() > 0
                      && request.resource.data.text.size() <= 2000
                      && request.resource.data.senderId == request.auth.uid;
        allow update, delete: if false;
      }
    }
  }
}
```

7. **iOS (optional)** — download `GoogleService-Info.plist`, put it in the repo
   root too. `app.config.js` only declares it when the file exists, so an
   Android-only checkout stays warning-free.

Nothing is hardcoded in JS. `src/lib/firebase.ts` reads the native config that
the `@react-native-firebase/app` plugin injects at build time.

---

## 4. Build an APK (the whole point)

```bash
npm install -g eas-cli
eas login
eas init                       # links the project, writes extra.eas.projectId

# installable APK (this is the profile you want)
eas build --profile preview --platform android
```

`eas.json` ships three profiles:

| Profile | Output | Use |
|---|---|---|
| `development` | debug APK | dev client, hot reload |
| `preview` | **release APK** | sideload / test on a real phone |
| `production` | AAB | Play Store |

Local equivalent, no cloud:

```bash
npx expo prebuild --clean
cd android && ./gradlew assembleRelease
```

---

## 5. Build configuration (why this one compiles)

Every item below is verified by actually running `expo prebuild` and
`expo export` on this repo.

| Concern | Where | Value |
|---|---|---|
| Compile SDK | `app.json` → `expo-build-properties` | `compileSdkVersion: 35`, `targetSdkVersion: 35`, `buildToolsVersion: "35.0.0"` |
| Min SDK | same | `24` (Firebase v21 requirement) |
| **New Architecture** | `app.json` → `newArchEnabled: false` | **also** force-written to `gradle.properties` by `plugins/with-firebase-jvm-args.js`, so `@react-native-firebase` stays on the old bridge |
| **Jetifier** | `plugins/with-firebase-jvm-args.js` | `android.enableJetifier=false` + `android.jetifier.ignorelist=bcprov` → no `bcprov-jdk18on` JDK-21 crash |
| JVM target | same plugin | pins all subprojects to Java/Kotlin **17** (Firebase is built at 17) |
| Gradle heap | same plugin | `org.gradle.jvmargs=-Xmx4096m …` → R8 + Firebase won't OOM on small EAS workers |
| Splash | `app.json` → `splash` | `backgroundColor: "#0A0A0A"` → the `splashscreen_background` resource always exists (confirmed in `res/values/colors.xml`) |
| Firebase plugin path | `app.json` → `plugins` | `"@react-native-firebase/app/app.plugin.js"` (literal, as requested) + `auth` plugin |
| iOS pods | `expo-build-properties` | `useFrameworks: "static"` + `forceStaticLinking` for `RNFBApp/RNFBAuth/RNFBFirestore` |

`expo-doctor`: **18/18 checks pass**.

### 5.1 About `kotlinVersion` — please read this one

You asked to force `kotlinVersion: "2.4.0"`. **I did not ship that**, on purpose:

* Kotlin 2.4.0 exists (JetBrains shipped it in June 2026), but React Native
  0.76.9's own Gradle plugin is compiled against **Kotlin 1.9.25**, and Expo
  SDK 52 generates an older Gradle/AGP pair than Kotlin 2.4 requires. Kotlin
  refuses to load build logic compiled by a newer compiler, so forcing 2.4.0
  fails while *evaluating the root project* — before a single line of your code
  is compiled. This is the exact "`A problem occurred evaluating root project`"
  class of failure you have been hitting.
* React Native also deprecated the `kotlinVersion` `ext` entirely in 0.77+, so a
  newer stack is the only real path if you want Kotlin 2.4.

Shipped value: **`1.9.25`** — the version React Native 0.76.9 compiles its own
Gradle plugin with, i.e. guaranteed-compatible. `compileSdkVersion: 35` is kept,
as requested.

**If you still want a different Kotlin version**, change exactly one line in
`app.json` (`expo-Build properties → android.kotlinVersion`). Values known to work on
SDK 52 are `1.9.24` / `1.9.25`. Anything ≥ 2.1 needs Expo SDK 54+ (RN 0.81),
where you can also drop the custom plugin.

---

## 6. Why there is no navigation library

A router means a route table (`/calculator`, `/vault`), a deep-link scheme, and
a navigation state that shows up in logs and debug menus. For a decoy app that
is a liability. Instead `App.tsx` is a two-state machine:

```ts
type Mode = 'calculator' | 'vault';
```

The vault mounts only when unlocked. Inside it, list → chat is an animated view
swap (`src/screens/Vault.tsx`) with the Android hardware back button remapped:
back inside a chat returns to the list, back on the list locks to the calculator.
Nothing is reachable by URL, and the calculator is a single render away at all
times (`Lock` button in both headers).

---

## 7. Project layout

```
.
├── App.tsx                        # calculator ⇄ vault state machine
├── app.json                       # plugins, build properties, splash
├── app.config.js                  # makes the iOS plist optional
├── eas.json                       # development / preview(APK) / production
├── index.ts                       # registerRootComponent
├── plugins/
│   └── with-firebase-jvm-args.js  # Jetifier + JVM-17 + heap hardening
├── scripts/
│   └── generate-assets.py         # regenerates icon/splash from geometry
├── src/
│   ├── components/
│   │   ├── Icons.tsx              # SVG icon set
│   │   └── Primitives.tsx         # CalcKey, Avatar, gradient
│   ├── lib/
│   │   ├── calculator.ts          # pure engine + secret-sequence detection
│   │   ├── chat.ts                # Firestore subscribe/send + demo fallback
│   │   ├── contacts.ts            # the 4 vault contacts
│   │   ├── firebase.ts            # anonymous auth, no keys
│   │   ├── secret.ts              # the trigger sequence, one place
│   │   └── time.ts                # WhatsApp-style timestamps
│   ├── screens/
│   │   ├── CalculatorScreen.tsx   # the decoy
│   │   ├── ChatListScreen.tsx     # vault index
│   │   ├── ChatScreen.tsx         # the room
│   │   └── Vault.tsx              # list ⇄ chat host
│   └── theme/index.ts             # colour/typography tokens
└── assets/                        # generated icons + splash
```

---

## 8. Firestore data model

```
rooms/{roomId}                          roomId = "room_navneet" | "room_shreya" | …
  contactId, name, members[]
  lastMessage, lastMessageAt, lastSenderId    ← powers the chat-list preview

rooms/{roomId}/messages/{messageId}
  text, senderId, senderName, createdAt (serverTimestamp), clientId
```

* `createdAt` is always a **server** timestamp; ordering never depends on a
  device clock.
* A send is a single **atomic batch** (message + room preview), so the list
  preview can never drift from the thread.
* `senderId === auth().currentUser.uid` decides green-vs-grey bubbles, so both
  phones render the same thread correctly.
* Every room document is created (idempotently) on first unlock.

---

## 9. Customising

| Want to change | File |
|---|---|
| The trigger sequence | `src/lib/secret.ts` (`SECRET_SEQUENCE`) |
| Contacts | `src/lib/contacts.ts` |
| Colours / type | `src/theme/index.ts` |
| App name & package | `app.json` (`name`, `android.package`, `ios.bundleIdentifier`) |
| Icons / splash | `python3 scripts/generate-assets.py` |
| Build profiles | `eas.json` |

To change the trigger to, say, `1 2 3 4 =`:

```ts
export const SECRET_SEQUENCE = ['1', '2', '3', '4', '='];
```

The matcher runs on the **raw keystream**, so any length works and the trigger
never has to be a valid sum.

---

## 10. Security note (be honest with yourself)

This is a *disguise*, not encryption:

* Messages live in plaintext in your Firestore project — anyone with console
  access (or your rules misconfigured) can read them.
* A determined person can find the app by its name in Settings, by the
  permission list, or by pulling the APK. Rename the launcher label to
  something boring if that matters (`app.json → expo.name`).
* Anonymous auth means "whoever holds the device" is the identity. There is no
  password to recover, and a reinstall creates a new UID.
* Before shipping: lock your rules down (§3), keep `google-services.json` out of
  git (already in `.gitignore`), and never reuse this package name for anything
  else.

---

## 11. Troubleshooting

| Symptom | Fix |
|---|---|
| `Cannot copy google-services.json…` | File missing from repo root, or the package name in `app.json` doesn't match the Firebase app. |
| `Path to google-services.json is not defined` | You removed `expo.android.googleServicesFile` — restore it. |
| Chat shows the demo banner | No Firebase config found, or Anonymous sign-in is disabled. |
| `DEFAULT_APP_NOT_FOUND` | `google-services.json` was added but the app wasn't rebuilt (`npx expo prebuild --clean`). |
| Build caching a stale native config | `npx expo prebuild --clean`, then rebuild. |
| Kotlin/AGP errors after editing versions | Put `kotlinVersion` back to `1.9.25` (§5.1). |
