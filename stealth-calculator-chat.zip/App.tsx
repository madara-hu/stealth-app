/**
 * App.tsx — the whole app is one state machine:
 *
 *   'calculator'  → the decoy shell (what the phone shows on launch)
 *   'vault'       → the hidden chat
 *
 * There is no navigator and no route table, so "vault" never appears in a
 * deep-link scheme, a navigation state dump, or an Android intent.
 */
import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Animated, Easing, StyleSheet, Text, View } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import * as SplashScreen from 'expo-splash-screen';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { CalculatorScreen } from './src/screens/CalculatorScreen';
import { Vault } from './src/screens/Vault';
import { ensureAnonymousSession, isFirebaseConfigured } from './src/lib/firebase';
import { palette, radius } from './src/theme';

// Keep the native splash up until the first frame is ready.
SplashScreen.preventAutoHideAsync().catch(() => undefined);

type Mode = 'calculator' | 'vault';

export default function App() {
  const [mode, setMode] = useState<Mode>('calculator');
  const [authError, setAuthError] = useState<string | null>(null);
  const [ready, setReady] = useState(false);
  const fade = useRef(new Animated.Value(1)).current;

  // Anonymous auth on boot — silent, and never blocks the calculator.
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        await ensureAnonymousSession();
      } catch (error) {
        if (!cancelled && __DEV__) {
          console.warn('[auth] anonymous sign-in failed:', error);
          setAuthError(
            error instanceof Error ? error.message : 'Anonymous sign-in failed'
          );
        }
      } finally {
        if (!cancelled) setReady(true);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    if (ready) {
      SplashScreen.hideAsync().catch(() => undefined);
    }
  }, [ready]);

  const goToVault = useCallback(() => {
    setMode((current) => {
      if (current === 'vault') return current;
      fade.setValue(0);
      // Defer one tick so the calculator's own fade-out finishes first.
      requestAnimationFrame(() => {
        Animated.timing(fade, {
          toValue: 1,
          duration: 260,
          easing: Easing.out(Easing.cubic),
          useNativeDriver: true,
        }).start();
      });
      return 'vault';
    });
  }, [fade]);

  const goToCalculator = useCallback(() => {
    fade.setValue(1);
    setMode('calculator');
  }, [fade]);

  return (
    <SafeAreaProvider>
      <StatusBar style="light" backgroundColor={palette.ink} />
      <View style={styles.root}>
        {mode === 'calculator' ? (
          <CalculatorScreen onUnlock={goToVault} />
        ) : (
          <Animated.View style={[styles.root, { opacity: fade }]}>
            <Vault onLock={goToCalculator} />
          </Animated.View>
        )}

        {/* Dev-only hint: never rendered in a release build. */}
        {__DEV__ && !isFirebaseConfigured() && mode === 'vault' ? (
          <View pointerEvents="none" style={styles.devToast}>
            <Text style={styles.devToastText}>
              Demo mode · add google-services.json to go live
            </Text>
          </View>
        ) : null}

        {__DEV__ && authError && mode === 'vault' ? (
          <View pointerEvents="none" style={styles.devToast}>
            <Text style={styles.devToastText} numberOfLines={2}>
              {authError}
            </Text>
          </View>
        ) : null}
      </View>
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: palette.ink,
  },
  devToast: {
    position: 'absolute',
    bottom: 18,
    alignSelf: 'center',
    maxWidth: '90%',
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: radius.pill,
    backgroundColor: 'rgba(0,224,122,0.12)',
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: 'rgba(0,224,122,0.3)',
  },
  devToastText: {
    color: 'rgba(167,243,208,0.95)',
    fontSize: 11,
    textAlign: 'center',
  },
});
