/**
 * app.config.js
 *
 * We start from app.json and apply two small runtime decisions:
 *
 *  1. iOS `googleServicesFile` is only declared when the plist actually exists.
 *     Declaring it unconditionally makes `expo config` warn
 *     ("Could not parse Expo config: ios.googleServicesFile") and makes iOS
 *     prebuild fail on machines that only build Android. Android keeps the
 *     path declared on purpose — the Firebase config plugin then fails fast
 *     with a clear message if you forget to drop google-services.json in.
 *
 *  2. Everything else — plugins, build properties, splash, newArchEnabled:false —
 *     stays declarative in app.json so a reviewer can read it in one glance.
 */
const fs = require('fs');
const path = require('path');

module.exports = ({ config }) => {
  const iosPlist = path.join(__dirname, 'GoogleService-Info.plist');
  const hasIosPlist = fs.existsSync(iosPlist);

  const nextConfig = {
    ...config,
    ios: {
      ...config.ios,
      ...(hasIosPlist ? { googleServicesFile: './GoogleService-Info.plist' } : {}),
    },
  };

  if (!hasIosPlist && nextConfig.ios) {
    delete nextConfig.ios.googleServicesFile;
  }

  return nextConfig;
};
