/**
 * Entry point. Kept tiny: importing the Firebase modules here (before React
 * mounts) means a missing google-services.json surfaces as a clear warning
 * instead of a late native crash inside a screen.
 */
import { registerRootComponent } from 'expo';
import App from './App';

registerRootComponent(App);
