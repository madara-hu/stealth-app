/**
 * Design tokens for the entire app.
 * Two personalities live here:
 *  - `calc`    → the calm, premium, monochrome dark calculator shell
 *  - `vault`   → the deep-black + neon emerald WhatsApp-style vault
 */
import { Platform } from 'react-native';

export const palette = {
  // Base surfaces
  black: '#000000',
  ink: '#0A0A0A',
  shell: '#0B0B0D',
  surface: '#141417',
  surfaceRaised: '#1C1C21',
  surfaceHigh: '#26262C',
  hairline: 'rgba(255,255,255,0.07)',
  hairlineStrong: 'rgba(255,255,255,0.12)',

  // Type
  textPrimary: '#F7F7F8',
  textSecondary: '#9A9AA5',
  textTertiary: '#6A6A75',

  // Calculator accents
  calcOp: '#1E1E24',
  calcOpText: '#00E07A',
  calcFn: '#2A2A31',
  calcFnText: '#F2F2F4',
  calcEquals: '#00E07A',
  calcEqualsText: '#001B0E',

  // Vault accents (emerald / neon green)
  emerald: '#00E07A',
  emeraldDeep: '#00A85C',
  emeraldInk: '#00220F',
  emeraldGlow: 'rgba(0, 224, 122, 0.35)',
  emeraldSoft: 'rgba(0, 224, 122, 0.12)',

  // Chat
  bubbleOut: '#075E54', // deep WhatsApp teal-green, premium variant
  bubbleOutAlt: '#0B6B5F',
  bubbleIn: '#1D1D22',
  bubbleText: '#F4F4F6',
  bubbleMeta: 'rgba(255,255,255,0.55)',
  bubbleMetaOut: 'rgba(0,224,122,0.75)',

  // Status
  danger: '#FF5A5F',
  warning: '#FFC857',
} as const;

export const radius = {
  xs: 8,
  sm: 12,
  md: 16,
  lg: 22,
  xl: 30,
  pill: 999,
} as const;

export const spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  xxl: 32,
} as const;

/** Slightly tighter tracking on iOS to match the platform's typography feel. */
export const font = {
  display: Platform.select({ ios: 'System', android: 'sans-serif-light', default: 'System' }) as string,
  regular: Platform.select({ ios: 'System', android: 'sans-serif', default: 'System' }) as string,
  medium: Platform.select({ ios: 'System', android: 'sans-serif-medium', default: 'System' }) as string,
} as const;

export const shadow = {
  card: {
    shadowColor: '#000',
    shadowOpacity: 0.45,
    shadowRadius: 18,
    shadowOffset: { width: 0, height: 10 },
    elevation: 10,
  },
  glow: {
    shadowColor: palette.emerald,
    shadowOpacity: 0.55,
    shadowRadius: 16,
    shadowOffset: { width: 0, height: 0 },
    elevation: 8,
  },
} as const;
