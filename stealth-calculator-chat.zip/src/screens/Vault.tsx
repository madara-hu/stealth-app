/**
 * Vault — route host for the hidden side of the app.
 *
 * Deliberately does NOT use a native navigator: a plain animated view swap
 * means no navigation library, no route-name leakage in logs, and no chance
 * of the vault being reachable by deep link or Android back-stack sniffing.
 */
import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Animated, BackHandler, Easing, StyleSheet, View } from 'react-native';
import type { Contact } from '../lib/contacts';
import { ChatListScreen } from './ChatListScreen';
import { ChatScreen } from './ChatScreen';
import { auth } from '../lib/firebase';
import { seedRooms } from '../lib/chat';
import { palette } from '../theme';

interface VaultProps {
  /** Return to the calculator shell. */
  onLock: () => void;
}

export const Vault: React.FC<VaultProps> = ({ onLock }) => {
  const [activeContact, setActiveContact] = useState<Contact | null>(null);
  const slide = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    seedRooms();
  }, []);

  // Android hardware back: close the chat first, then lock the vault.
  useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      if (activeContact) {
        setActiveContact(null);
        return true;
      }
      onLock();
      return true;
    });
    return () => sub.remove();
  }, [activeContact, onLock]);

  const openContact = useCallback(
    (contact: Contact) => {
      setActiveContact(contact);
      slide.setValue(0);
      Animated.timing(slide, {
        toValue: 1,
        duration: 220,
        easing: Easing.out(Easing.cubic),
        useNativeDriver: true,
      }).start();
    },
    [slide]
  );

  const closeContact = useCallback(() => {
    Animated.timing(slide, {
      toValue: 0,
      duration: 160,
      easing: Easing.in(Easing.quad),
      useNativeDriver: true,
    }).start(() => setActiveContact(null));
  }, [slide]);

  const translateX = slide.interpolate({
    inputRange: [0, 1],
    outputRange: [40, 0],
  });

  return (
    <View style={styles.root}>
      <ChatListScreen
        onOpenContact={openContact}
        onLock={onLock}
        currentUid={auth().currentUser?.uid ?? 'local-user'}
      />

      {activeContact ? (
        <Animated.View
          style={[StyleSheet.absoluteFillObject, { opacity: slide, transform: [{ translateX }] }]}
        >
          <ChatScreen
            contact={activeContact}
            onBack={closeContact}
            onLock={onLock}
          />
        </Animated.View>
      ) : null}
    </View>
  );
};

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: palette.ink,
  },
});
