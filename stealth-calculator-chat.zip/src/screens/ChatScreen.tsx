/**
 * ChatScreen — the room itself.
 *
 * • Inverted list so new messages pin to the bottom with correct keyboard
 *   behaviour on both platforms (the classic RN chat-list approach).
 * • Bubbles: outgoing = deep emerald-teal, incoming = graphite.
 * • Ticks, timestamps, day dividers, and an optimistic "sending" state so the
 *   UI never feels laggy even on a cold Firestore connection.
 * • "Lock" in the header is the instant escape hatch back to the calculator.
 */
import React, { useCallback, useMemo, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Animated,
  FlatList,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  StatusBar,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import * as Haptics from 'expo-haptics';
import type { Contact } from '../lib/contacts';
import { sendMessage, useMessages, type ChatMessage } from '../lib/chat';
import { formatClock, formatDayDivider } from '../lib/time';
import { Avatar } from '../components/Primitives';
import {
  BackIcon,
  CheckIcon,
  LockIcon,
  PhoneIcon,
  SendIcon,
  ShieldIcon,
  VideoIcon,
} from '../components/Icons';
import { palette, radius, spacing } from '../theme';

interface ChatScreenProps {
  contact: Contact;
  onBack: () => void;
  onLock: () => void;
}

interface Row {
  type: 'message' | 'divider';
  key: string;
  message?: ChatMessage;
  label?: string;
}

const sameDay = (a: number | null, b: number | null) => {
  if (!a || !b) return false;
  const da = new Date(a);
  const db = new Date(b);
  return (
    da.getDate() === db.getDate() &&
    da.getMonth() === db.getMonth() &&
    da.getFullYear() === db.getFullYear()
  );
};

export const ChatScreen: React.FC<ChatScreenProps> = ({ contact, onBack, onLock }) => {
  const { messages, loading, error, myUid } = useMessages(contact.id);
  const [draft, setDraft] = useState('');
  const [sending, setSending] = useState(false);
  const sendScale = useRef(new Animated.Value(1)).current;

  /** Build the inverted list: newest first + day dividers between clusters. */
  const rows = useMemo<Row[]>(() => {
    const out: Row[] = [];
    for (let i = messages.length - 1; i >= 0; i -= 1) {
      const message = messages[i];
      out.push({ type: 'message', key: message.id, message });
      const previous = messages[i - 1];
      if (
        message.createdAt &&
        (!previous || !sameDay(previous.createdAt, message.createdAt))
      ) {
        out.push({
          type: 'divider',
          key: `divider_${message.id}`,
          label: formatDayDivider(message.createdAt),
        });
      }
    }
    return out;
  }, [messages]);

  const handleSend = useCallback(async () => {
    const text = draft.trim();
    if (!text || sending) return;

    Animated.sequence([
      Animated.timing(sendScale, { toValue: 0.86, duration: 80, useNativeDriver: true }),
      Animated.spring(sendScale, {
        toValue: 1,
        useNativeDriver: true,
        friction: 4,
        tension: 140,
      }),
    ]).start();

    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light).catch(() => undefined);
    setDraft('');
    setSending(true);
    try {
      await sendMessage(contact, text);
    } catch (err) {
      if (__DEV__) console.warn('[sendMessage]', err);
      setDraft(text); // give the text back rather than losing it
    } finally {
      setSending(false);
    }
  }, [contact, draft, sending, sendScale]);

  const renderRow = ({ item }: { item: Row }) => {
    if (item.type === 'divider') {
      return (
        <View style={styles.dividerWrap}>
          <View style={styles.divider}>
            <Text style={styles.dividerText}>{item.label}</Text>
          </View>
        </View>
      );
    }

    const message = item.message!;
    const mine = message.senderId === myUid;
    const system = message.senderId === 'system';

    if (system) {
      return (
        <View style={styles.systemWrap}>
          <View style={styles.systemChip}>
            <ShieldIcon size={11} color={palette.emeraldDeep} />
            <Text style={styles.systemText}>{message.text}</Text>
          </View>
        </View>
      );
    }

    return (
      <View style={[styles.bubbleRow, mine ? styles.bubbleRowMine : styles.bubbleRowTheirs]}>
        <View style={[styles.bubble, mine ? styles.bubbleOut : styles.bubbleIn]}>
          <Text style={styles.bubbleText}>{message.text}</Text>
          <View style={styles.metaRow}>
            <Text style={[styles.metaText, mine && styles.metaTextOut]}>
              {formatClock(message.createdAt) || '…'}
            </Text>
            {mine ? <CheckIcon size={12} color={palette.bubbleMetaOut} /> : null}
          </View>
        </View>
      </View>
    );
  };

  return (
    <View style={styles.root}>
      <StatusBar barStyle="light-content" backgroundColor={palette.surface} />
      <SafeAreaView style={styles.safe} edges={['top']}>
        {/* ── header ──────────────────────────────────────────────────────── */}
        <View style={styles.header}>
          <Pressable
            hitSlop={12}
            onPress={() => {
              Haptics.selectionAsync().catch(() => undefined);
              onBack();
            }}
            style={({ pressed }) => [styles.backBtn, pressed && styles.pressed]}
          >
            <BackIcon size={22} color={palette.textPrimary} />
          </Pressable>

          <View style={styles.headerBody}>
            <Avatar
              initials={contact.initials}
              accent={contact.accent}
              size={38}
              online={contact.presence === 'online'}
            />
            <View style={styles.headerText}>
              <Text style={styles.headerName} numberOfLines={1}>
                {contact.name}
              </Text>
              <Text style={styles.headerStatus} numberOfLines={1}>
                {contact.presence === 'online' ? 'online' : contact.status}
              </Text>
            </View>
          </View>

          <View style={styles.headerActions}>
            <Pressable hitSlop={8} style={({ pressed }) => [styles.ghostBtn, pressed && styles.pressed]}>
              <PhoneIcon size={18} color={palette.textSecondary} />
            </Pressable>
            <Pressable hitSlop={8} style={({ pressed }) => [styles.ghostBtn, pressed && styles.pressed]}>
              <VideoIcon size={19} color={palette.textSecondary} />
            </Pressable>
            <Pressable
              hitSlop={10}
              accessibilityLabel="Lock vault"
              onPress={() => {
                Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium).catch(
                  () => undefined
                );
                onLock();
              }}
              style={({ pressed }) => [styles.lockBtn, pressed && styles.lockBtnPressed]}
            >
              <LockIcon size={16} color={palette.emerald} />
            </Pressable>
          </View>
        </View>

        {/* ── messages ────────────────────────────────────────────────────── */}
        <KeyboardAvoidingView
          style={styles.flex}
          behavior={Platform.OS === 'ios' ? 'padding' : undefined}
          keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : 0}
        >
          {error ? (
            <View style={styles.banner}>
              <Text style={styles.bannerText} numberOfLines={3}>
                {error}
              </Text>
            </View>
          ) : null}

          {loading ? (
            <View style={styles.loading}>
              <ActivityIndicator color={palette.emerald} />
            </View>
          ) : (
            <FlatList
              data={rows}
              inverted
              keyExtractor={(item) => item.key}
              renderItem={renderRow}
              contentContainerStyle={styles.listContent}
              keyboardShouldPersistTaps="handled"
              showsVerticalScrollIndicator={false}
              ListEmptyComponent={
                <View style={styles.emptyWrap}>
                  <View style={styles.emptyIcon}>
                    <ShieldIcon size={22} color={palette.emerald} />
                  </View>
                  <Text style={styles.emptyTitle}>Vault line opened</Text>
                  <Text style={styles.emptyText}>
                    Say something to {contact.name}. Only you two can read this thread.
                  </Text>
                </View>
              }
            />
          )}

          {/* ── composer ──────────────────────────────────────────────────── */}
          <View style={styles.composerWrap}>
            <View style={styles.composer}>
              <TextInput
                value={draft}
                onChangeText={setDraft}
                placeholder="Message"
                placeholderTextColor={palette.textTertiary}
                style={styles.input}
                multiline
                maxLength={2000}
                selectionColor={palette.emerald}
                underlineColorAndroid="transparent"
              />
              <Animated.View style={{ transform: [{ scale: sendScale }] }}>
                <Pressable
                  onPress={handleSend}
                  disabled={!draft.trim()}
                  style={({ pressed }) => [
                    styles.sendBtn,
                    !draft.trim() && styles.sendBtnIdle,
                    pressed && styles.sendBtnPressed,
                  ]}
                >
                  {sending ? (
                    <ActivityIndicator size="small" color={palette.emeraldInk} />
                  ) : (
                    <SendIcon size={18} color={palette.emeraldInk} />
                  )}
                </Pressable>
              </Animated.View>
            </View>
            <View style={styles.composerMeta}>
              <LockIcon size={10} color={palette.textTertiary} strokeWidth={2.2} />
              <Text style={styles.composerMetaText}>
                End-to-end private · Firestore
              </Text>
            </View>
          </View>
        </KeyboardAvoidingView>
      </SafeAreaView>
    </View>
  );
};

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: palette.ink,
  },
  safe: {
    flex: 1,
  },
  flex: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: spacing.sm,
    paddingVertical: 10,
    gap: 4,
    backgroundColor: palette.surface,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: palette.hairline,
  },
  backBtn: {
    width: 34,
    height: 34,
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerBody: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  headerText: {
    flex: 1,
  },
  headerName: {
    color: palette.textPrimary,
    fontSize: 16,
    fontWeight: '600',
    letterSpacing: -0.2,
  },
  headerStatus: {
    color: palette.emerald,
    fontSize: 11.5,
    marginTop: 1,
  },
  headerActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 2,
  },
  ghostBtn: {
    width: 34,
    height: 34,
    alignItems: 'center',
    justifyContent: 'center',
  },
  pressed: {
    opacity: 0.55,
  },
  lockBtn: {
    width: 38,
    height: 38,
    marginLeft: 4,
    borderRadius: radius.pill,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(0,224,122,0.10)',
    borderWidth: 1,
    borderColor: 'rgba(0,224,122,0.32)',
  },
  lockBtnPressed: {
    transform: [{ scale: 0.93 }],
    opacity: 0.85,
  },
  banner: {
    margin: spacing.md,
    padding: spacing.md,
    borderRadius: radius.sm,
    backgroundColor: 'rgba(255,90,95,0.10)',
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: 'rgba(255,90,95,0.35)',
  },
  bannerText: {
    color: '#FFB3B6',
    fontSize: 12,
    lineHeight: 17,
  },
  loading: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  listContent: {
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.md,
    flexGrow: 1,
  },
  bubbleRow: {
    flexDirection: 'row',
    marginBottom: 6,
  },
  bubbleRowMine: {
    justifyContent: 'flex-end',
  },
  bubbleRowTheirs: {
    justifyContent: 'flex-start',
  },
  bubble: {
    maxWidth: '80%',
    paddingHorizontal: 13,
    paddingTop: 9,
    paddingBottom: 6,
    borderRadius: 18,
  },
  bubbleOut: {
    backgroundColor: palette.bubbleOut,
    borderBottomRightRadius: 6,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: 'rgba(0,224,122,0.22)',
  },
  bubbleIn: {
    backgroundColor: palette.bubbleIn,
    borderBottomLeftRadius: 6,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: palette.hairline,
  },
  bubbleText: {
    color: palette.bubbleText,
    fontSize: 15,
    lineHeight: 21,
  },
  metaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-end',
    gap: 4,
    marginTop: 3,
  },
  metaText: {
    color: palette.bubbleMeta,
    fontSize: 10,
    letterSpacing: 0.2,
  },
  metaTextOut: {
    color: palette.bubbleMetaOut,
  },
  dividerWrap: {
    alignItems: 'center',
    marginVertical: spacing.md,
  },
  divider: {
    paddingHorizontal: 12,
    paddingVertical: 5,
    borderRadius: radius.pill,
    backgroundColor: palette.surface,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: palette.hairline,
  },
  dividerText: {
    color: palette.textTertiary,
    fontSize: 10,
    fontWeight: '700',
    letterSpacing: 1.2,
  },
  systemWrap: {
    alignItems: 'center',
    marginVertical: spacing.sm,
  },
  systemChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    maxWidth: '88%',
    paddingHorizontal: 12,
    paddingVertical: 7,
    borderRadius: radius.sm,
    backgroundColor: 'rgba(0,224,122,0.07)',
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: 'rgba(0,224,122,0.22)',
  },
  systemText: {
    flexShrink: 1,
    color: 'rgba(167,243,208,0.9)',
    fontSize: 11.5,
    lineHeight: 16,
  },
  emptyWrap: {
    alignItems: 'center',
    paddingHorizontal: spacing.xl,
    paddingVertical: spacing.xxl,
    transform: [{ scaleY: -1 }], // counter the inverted list
  },
  emptyIcon: {
    width: 52,
    height: 52,
    borderRadius: 26,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(0,224,122,0.10)',
    borderWidth: 1,
    borderColor: 'rgba(0,224,122,0.3)',
    marginBottom: spacing.md,
  },
  emptyTitle: {
    color: palette.textPrimary,
    fontSize: 15,
    fontWeight: '600',
    marginBottom: 6,
  },
  emptyText: {
    color: palette.textTertiary,
    fontSize: 12.5,
    textAlign: 'center',
    lineHeight: 18,
  },
  composerWrap: {
    paddingHorizontal: spacing.md,
    paddingTop: spacing.sm,
    paddingBottom: spacing.sm,
    backgroundColor: palette.ink,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: palette.hairline,
  },
  composer: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    gap: 8,
    paddingLeft: 16,
    paddingRight: 6,
    paddingVertical: 6,
    borderRadius: radius.xl,
    backgroundColor: palette.surface,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: palette.hairlineStrong,
  },
  input: {
    flex: 1,
    color: palette.textPrimary,
    fontSize: 15.5,
    lineHeight: 21,
    maxHeight: 120,
    paddingTop: Platform.OS === 'ios' ? 9 : 8,
    paddingBottom: Platform.OS === 'ios' ? 9 : 8,
  },
  sendBtn: {
    width: 42,
    height: 42,
    borderRadius: 21,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: palette.emerald,
    shadowColor: palette.emerald,
    shadowOpacity: 0.5,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 2 },
    elevation: 6,
  },
  sendBtnIdle: {
    backgroundColor: palette.surfaceHigh,
    shadowOpacity: 0,
    elevation: 0,
  },
  sendBtnPressed: {
    transform: [{ scale: 0.94 }],
  },
  composerMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 5,
    paddingTop: 6,
  },
  composerMetaText: {
    color: palette.textTertiary,
    fontSize: 10,
    letterSpacing: 0.3,
  },
});
