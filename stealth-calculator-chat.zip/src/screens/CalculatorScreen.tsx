/**
 * CalculatorScreen — the "outer shell".
 *
 * Design intent: it must look like a finished, expensive, App Store-grade
 * calculator, because nobody hides a secret behind an app that looks fake.
 * Deep black, oversized light-weight numerals, pill keys, emerald operator
 * accents, and a slow-breathing emerald halo behind the display.
 */
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Animated, Easing, StatusBar, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import * as Haptics from 'expo-haptics';
import { CalcKey, type KeyVariant } from '../components/Primitives';
import { KeypadIcon } from '../components/Icons';
import { initialState, pressKey, type CalcState } from '../lib/calculator';
import { palette, radius, spacing } from '../theme';

interface KeyDef {
  label: string;
  variant: KeyVariant;
  wide?: boolean;
}

const KEYS: KeyDef[] = [
  { label: 'AC', variant: 'fn' },
  { label: '+/-', variant: 'fn' },
  { label: '%', variant: 'fn' },
  { label: '÷', variant: 'operator' },
  { label: '7', variant: 'digit' },
  { label: '8', variant: 'digit' },
  { label: '9', variant: 'digit' },
  { label: '×', variant: 'operator' },
  { label: '4', variant: 'digit' },
  { label: '5', variant: 'digit' },
  { label: '6', variant: 'digit' },
  { label: '-', variant: 'operator' },
  { label: '1', variant: 'digit' },
  { label: '2', variant: 'digit' },
  { label: '3', variant: 'digit' },
  { label: '+', variant: 'operator' },
  { label: '0', variant: 'digit', wide: true },
  { label: '.', variant: 'digit' },
  { label: '=', variant: 'equals' },
];

const haptic = (style: Haptics.ImpactFeedbackStyle) => {
  Haptics.impactAsync(style).catch(() => {
    /* haptics unavailable (e.g. web/simulator) — never block input */
  });
};

interface CalculatorScreenProps {
  /** Fired when the secret sequence is completed. */
  onUnlock: () => void;
}

export const CalculatorScreen: React.FC<CalculatorScreenProps> = ({ onUnlock }) => {
  const [state, setState] = useState<CalcState>(initialState);

  const glow = useRef(new Animated.Value(0)).current;
  const unlock = useRef(new Animated.Value(1)).current;
  const displayFade = useRef(new Animated.Value(1)).current;

  // Slow breathing halo behind the display — subtle, 6s, never distracting.
  useEffect(() => {
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(glow, {
          toValue: 1,
          duration: 3200,
          easing: Easing.inOut(Easing.quad),
          useNativeDriver: true,
        }),
        Animated.timing(glow, {
          toValue: 0,
          duration: 3200,
          easing: Easing.inOut(Easing.quad),
          useNativeDriver: true,
        }),
      ])
    );
    loop.start();
    return () => loop.stop();
  }, [glow]);

  // Flash the display whenever a new value lands, so taps feel physical.
  useEffect(() => {
    displayFade.setValue(0.72);
    Animated.timing(displayFade, {
      toValue: 1,
      duration: 180,
      easing: Easing.out(Easing.quad),
      useNativeDriver: true,
    }).start();
  }, [state.display, displayFade]);

  const triggerUnlock = useCallback(() => {
    haptic(Haptics.ImpactFeedbackStyle.Heavy);
    Animated.timing(unlock, {
      toValue: 0,
      duration: 220,
      easing: Easing.in(Easing.quad),
      useNativeDriver: true,
    }).start(() => {
      onUnlock();
      // Restore the shell instantly so it is pristine on the way back.
      unlock.setValue(1);
      setState(initialState);
    });
  }, [onUnlock, unlock]);

  const onKey = useCallback(
    (key: string) => {
      haptic(
        key === '=' ? Haptics.ImpactFeedbackStyle.Medium : Haptics.ImpactFeedbackStyle.Light
      );
      setState((prev) => pressKey(prev, key, triggerUnlock));
    },
    [triggerUnlock]
  );

  const displayFontSize = useMemo(() => {
    const len = state.display.length;
    if (len <= 6) return 84;
    if (len <= 8) return 70;
    if (len <= 10) return 58;
    return 46;
  }, [state.display.length]);

  const glowStyle = {
    opacity: glow.interpolate({ inputRange: [0, 1], outputRange: [0.25, 0.6] }),
    transform: [
      { scale: glow.interpolate({ inputRange: [0, 1], outputRange: [0.92, 1.06] }) },
    ],
  };

  return (
    <Animated.View style={[styles.root, { opacity: unlock }]}>
      <StatusBar barStyle="light-content" backgroundColor={palette.ink} />
      <SafeAreaView style={styles.safe} edges={['top', 'bottom']}>
        {/* ── top bar: brand + keypad glyph, purely decorative ───────────── */}
        <View style={styles.topBar}>
          <View style={styles.brandRow}>
            <View style={styles.brandDot} />
            <Text style={styles.brand}>Calculator</Text>
          </View>
          <View style={styles.keypadChip}>
            <KeypadIcon size={16} color={palette.textSecondary} />
            <Text style={styles.keypadChipText}>Standard</Text>
          </View>
        </View>

        {/* ── display ─────────────────────────────────────────────────────── */}
        <View style={styles.displayZone}>
          <Animated.View style={[styles.halo, glowStyle]} />

          <View style={styles.displayInner}>
            <Text style={styles.expression} numberOfLines={1}>
              {state.error ?? state.expression ?? ''}
            </Text>
            <Animated.Text
              style={[
                styles.displayValue,
                { fontSize: displayFontSize, opacity: displayFade },
                state.error ? styles.displayError : null,
              ]}
              numberOfLines={1}
              adjustsFontSizeToFit
              minimumFontScale={0.4}
            >
              {state.display}
            </Animated.Text>
          </View>
        </View>

        {/* ── keypad ──────────────────────────────────────────────────────── */}
        <View style={styles.keypad}>
          {[0, 1, 2, 3, 4].map((row) => (
            <View style={styles.keyRow} key={`row-${row}`}>
              {KEYS.slice(row * 4, row * 4 + 4).map((k) => (
                <CalcKey
                  key={k.label}
                  label={k.label}
                  variant={k.variant}
                  wide={k.wide}
                  onPress={onKey}
                />
              ))}
            </View>
          ))}
        </View>

        <View style={styles.homeBar}>
          <View style={styles.homeBarPill} />
        </View>
      </SafeAreaView>
    </Animated.View>
  );
};

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: palette.ink,
  },
  safe: {
    flex: 1,
    paddingHorizontal: spacing.lg,
  },
  topBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingTop: spacing.sm,
    paddingBottom: spacing.md,
  },
  brandRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  brandDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: palette.emerald,
    shadowColor: palette.emerald,
    shadowOpacity: 0.9,
    shadowRadius: 6,
    shadowOffset: { width: 0, height: 0 },
    elevation: 4,
  },
  brand: {
    color: palette.textSecondary,
    fontSize: 13,
    letterSpacing: 2.4,
    fontWeight: '600',
  },
  keypadChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 7,
    borderRadius: radius.pill,
    backgroundColor: palette.surface,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: palette.hairline,
  },
  keypadChipText: {
    color: palette.textSecondary,
    fontSize: 11.5,
    letterSpacing: 0.6,
    fontWeight: '600',
  },
  displayZone: {
    flex: 1,
    justifyContent: 'flex-end',
    paddingBottom: spacing.lg,
  },
  halo: {
    position: 'absolute',
    right: -70,
    bottom: 0,
    width: 250,
    height: 250,
    borderRadius: 125,
    backgroundColor: palette.emeraldGlow,
  },
  displayInner: {
    alignItems: 'flex-end',
  },
  expression: {
    color: palette.textTertiary,
    fontSize: 17,
    letterSpacing: 0.4,
    marginBottom: 6,
    minHeight: 22,
  },
  displayValue: {
    color: palette.textPrimary,
    fontWeight: '300',
    letterSpacing: -2,
    includeFontPadding: false,
    textAlign: 'right',
  },
  displayError: {
    color: palette.danger,
    fontSize: 40,
  },
  keypad: {
    paddingTop: spacing.sm,
    marginHorizontal: -5,
  },
  keyRow: {
    flexDirection: 'row',
  },
  homeBar: {
    alignItems: 'center',
    paddingTop: spacing.sm,
    paddingBottom: spacing.xs,
  },
  homeBarPill: {
    width: 118,
    height: 4.5,
    borderRadius: 3,
    backgroundColor: 'rgba(255,255,255,0.18)',
  },
});
