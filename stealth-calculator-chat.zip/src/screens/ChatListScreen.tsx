/**
 * ChatListScreen — the WhatsApp-style vault index.
 *
 * Premium touches that keep it from looking like a stock clone:
 *  • a soft emerald aurora bleeding in from the top-left
 *  • a "Vault" wordmark with a shield + encryption subline
 *  • floating search field with a real glass feel
 *  • avatar monograms instead of stock photos (no asset bundling)
 *  • per-row delivery preview ("You: …" / tick) and relative timestamps
 */
import React, { useMemo, useState } from 'react';
import {
  FlatList,
  Pressable,
  StatusBar,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import * as Haptics from 'expo-haptics';
import { CONTACTS, type Contact } from '../lib/contacts';
import { useRoomSummaries } from '../lib/chat';
import { formatListTime } from '../lib/time';
import { Avatar } from '../components/Primitives';
import { CheckIcon, LockIcon, MoreIcon, SearchIcon, ShieldIcon } from '../components/Icons';
import { palette, radius, spacing } from '../theme';

interface ChatListScreenProps {
  onOpenContact: (contact: Contact) => void;
  onLock: () => void;
  currentUid?: string | null;
}

export const ChatListScreen: React.FC<ChatListScreenProps> = ({
  onOpenContact,
  onLock,
  currentUid,
}) => {
  const [query, setQuery] = useState('');
  const rooms = useRoomSummaries();

  const data = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return CONTACTS;
    return CONTACTS.filter(
      (c) =>
        c.name.toLowerCase().includes(q) || c.status.toLowerCase().includes(q)
    );
  }, [query]);

  const renderItem = ({ item, index }: { item: Contact; index: number }) => {
    const summary = rooms[item.id];
    const preview = summary?.lastMessage?.trim();
    const mine = !!summary?.lastSenderId && summary.lastSenderId === currentUid;
    const isLast = index === data.length - 1;

    return (
      <Pressable
        onPress={() => {
          Haptics.selectionAsync().catch(() => undefined);
          onOpenContact(item);
        }}
        android_ripple={{ color: 'rgba(0,224,122,0.08)' }}
        style={({ pressed }) => [styles.row, pressed && styles.rowPressed]}
      >
        <Avatar
          initials={item.initials}
          accent={item.accent}
          size={54}
          online={item.presence === 'online'}
        />

        <View style={[styles.rowBody, !isLast && styles.rowBodyDivider]}>
          <View style={styles.rowTop}>
            <Text style={styles.rowName} numberOfLines={1}>
              {item.name}
            </Text>
            <Text style={styles.rowTime}>
              {formatListTime(summary?.lastMessageAt ?? null) || item.presence}
            </Text>
          </View>

          <View style={styles.rowBottom}>
            <View style={styles.previewWrap}>
              {mine ? <CheckIcon size={13} color={palette.emerald} /> : null}
              <Text
                style={[styles.rowPreview, mine && styles.rowPreviewMine]}
                numberOfLines={1}
              >
                {preview || item.status}
              </Text>
            </View>
            <View style={styles.encryptedChip}>
              <LockIcon size={11} color={palette.emeraldDeep} strokeWidth={2} />
            </View>
          </View>
        </View>
      </Pressable>
    );
  };

  return (
    <View style={styles.root}>
      <StatusBar barStyle="light-content" backgroundColor={palette.ink} />
      <SafeAreaView style={styles.safe} edges={['top', 'bottom']}>
        {/* aurora */}
        <View pointerEvents="none" style={styles.aurora} />
        <View pointerEvents="none" style={styles.auroraTwo} />

        {/* header */}
        <View style={styles.header}>
          <View>
            <View style={styles.titleRow}>
              <Text style={styles.title}>Vault</Text>
              <View style={styles.titleBadge}>
                <ShieldIcon size={13} color={palette.emerald} />
                <Text style={styles.titleBadgeText}>PRIVATE</Text>
              </View>
            </View>
            <Text style={styles.subtitle}>4 encrypted lines · no backups</Text>
          </View>

          <View style={styles.headerActions}>
            <Pressable
              hitSlop={10}
              style={({ pressed }) => [styles.iconBtn, pressed && styles.iconBtnPressed]}
              onPress={() => Haptics.selectionAsync().catch(() => undefined)}
            >
              <MoreIcon size={19} color={palette.textSecondary} />
            </Pressable>
            <Pressable
              hitSlop={12}
              accessibilityLabel="Lock vault and return to calculator"
              onPress={() => {
                Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium).catch(
                  () => undefined
                );
                onLock();
              }}
              style={({ pressed }) => [styles.lockBtn, pressed && styles.lockBtnPressed]}
            >
              <LockIcon size={18} color={palette.emerald} />
            </Pressable>
          </View>
        </View>

        {/* search */}
        <View style={styles.searchWrap}>
          <SearchIcon size={17} color={palette.textTertiary} />
          <TextInput
            value={query}
            onChangeText={setQuery}
            placeholder="Search vault"
            placeholderTextColor={palette.textTertiary}
            style={styles.searchInput}
            selectionColor={palette.emerald}
            autoCorrect={false}
            returnKeyType="search"
          />
        </View>

        {/* list */}
        <FlatList
          data={data}
          keyExtractor={(item) => item.id}
          renderItem={renderItem}
          contentContainerStyle={styles.listContent}
          showsVerticalScrollIndicator={false}
          ListFooterComponent={
            <View style={styles.footer}>
              <ShieldIcon size={13} color={palette.textTertiary} />
              <Text style={styles.footerText}>
                Messages are stored in your private Firebase project
              </Text>
            </View>
          }
        />
      </SafeAreaView>
    </View>
  );
};

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: palette.ink,
  },
  safe: {
    flex: 1,
  },
  aurora: {
    position: 'absolute',
    top: -140,
    left: -110,
    width: 340,
    height: 340,
    borderRadius: 170,
    backgroundColor: 'rgba(0,224,122,0.10)',
  },
  auroraTwo: {
    position: 'absolute',
    top: 40,
    right: -160,
    width: 300,
    height: 300,
    borderRadius: 150,
    backgroundColor: 'rgba(0,224,122,0.05)',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.xl,
    paddingTop: spacing.md,
    paddingBottom: spacing.lg,
  },
  titleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  title: {
    color: palette.textPrimary,
    fontSize: 30,
    fontWeight: '700',
    letterSpacing: -0.8,
  },
  titleBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: radius.pill,
    backgroundColor: palette.emeraldSoft,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: 'rgba(0,224,122,0.3)',
  },
  titleBadgeText: {
    color: palette.emerald,
    fontSize: 9,
    fontWeight: '800',
    letterSpacing: 1.1,
  },
  subtitle: {
    color: palette.textTertiary,
    fontSize: 12.5,
    marginTop: 5,
    letterSpacing: 0.2,
  },
  headerActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  iconBtn: {
    width: 40,
    height: 40,
    borderRadius: radius.pill,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: palette.surface,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: palette.hairline,
  },
  iconBtnPressed: {
    opacity: 0.6,
  },
  lockBtn: {
    width: 44,
    height: 44,
    borderRadius: radius.pill,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(0,224,122,0.10)',
    borderWidth: 1,
    borderColor: 'rgba(0,224,122,0.35)',
    shadowColor: palette.emerald,
    shadowOpacity: 0.35,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 0 },
    elevation: 6,
  },
  lockBtnPressed: {
    transform: [{ scale: 0.94 }],
    opacity: 0.85,
  },
  searchWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginHorizontal: spacing.xl,
    marginBottom: spacing.md,
    paddingHorizontal: 15,
    height: 46,
    borderRadius: radius.md,
    backgroundColor: palette.surface,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: palette.hairline,
  },
  searchInput: {
    flex: 1,
    color: palette.textPrimary,
    fontSize: 15,
    paddingVertical: 0,
  },
  listContent: {
    paddingHorizontal: spacing.md,
    paddingBottom: spacing.xl,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    paddingLeft: spacing.md,
    paddingRight: spacing.sm,
    paddingTop: 12,
    paddingBottom: 12,
    borderRadius: radius.lg,
  },
  rowPressed: {
    backgroundColor: 'rgba(255,255,255,0.035)',
  },
  rowBody: {
    flex: 1,
    paddingBottom: 14,
  },
  rowBodyDivider: {
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: palette.hairline,
  },
  rowTop: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 5,
    gap: 8,
  },
  rowName: {
    flex: 1,
    color: palette.textPrimary,
    fontSize: 16.5,
    fontWeight: '600',
    letterSpacing: -0.2,
  },
  rowTime: {
    color: palette.textTertiary,
    fontSize: 11.5,
    letterSpacing: 0.2,
  },
  rowBottom: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 10,
  },
  previewWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    flex: 1,
  },
  rowPreview: {
    flex: 1,
    color: palette.textSecondary,
    fontSize: 13.5,
  },
  rowPreviewMine: {
    color: 'rgba(0,224,122,0.72)',
  },
  encryptedChip: {
    width: 22,
    height: 22,
    borderRadius: 11,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(0,224,122,0.08)',
  },
  footer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 7,
    paddingTop: spacing.xl,
    paddingHorizontal: spacing.xl,
  },
  footerText: {
    color: palette.textTertiary,
    fontSize: 11.5,
    textAlign: 'center',
  },
});
