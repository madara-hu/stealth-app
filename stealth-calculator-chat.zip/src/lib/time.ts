/**
 * Time helpers — WhatsApp-style, no dependencies.
 */

const pad = (n: number) => (n < 10 ? `0${n}` : String(n));

export const formatClock = (millis: number | null): string => {
  if (!millis) return '';
  const d = new Date(millis);
  return `${pad(d.getHours())}:${pad(d.getMinutes())}`;
};

export const formatListTime = (millis: number | null): string => {
  if (!millis) return '';
  const d = new Date(millis);
  const now = new Date();
  const sameDay =
    d.getDate() === now.getDate() &&
    d.getMonth() === now.getMonth() &&
    d.getFullYear() === now.getFullYear();
  if (sameDay) return formatClock(millis);

  const yesterday = new Date(now);
  yesterday.setDate(now.getDate() - 1);
  const isYesterday =
    d.getDate() === yesterday.getDate() &&
    d.getMonth() === yesterday.getMonth() &&
    d.getFullYear() === yesterday.getFullYear();
  if (isYesterday) return 'Yesterday';

  return `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${String(
    d.getFullYear()
  ).slice(2)}`;
};

export const formatDayDivider = (millis: number | null): string => {
  if (!millis) return '';
  const d = new Date(millis);
  const now = new Date();
  const sameDay =
    d.getDate() === now.getDate() &&
    d.getMonth() === now.getMonth() &&
    d.getFullYear() === now.getFullYear();
  if (sameDay) return 'TODAY';
  return `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()}`;
};
