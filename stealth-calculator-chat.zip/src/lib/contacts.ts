/**
 * The 4 vault contacts. Order matters — this is exactly how they render.
 * Seeded into Firestore on first launch (deterministic doc ids = idempotent).
 */

export type ContactId = 'navneet' | 'shreya' | 'navya' | 'wons';

export interface Contact {
  id: ContactId;
  name: string;
  /** Short status line under the name in the chat list. */
  status: string;
  /** Two-letter monogram for the avatar. */
  initials: string;
  /** Avatar accent (kept in the emerald/graphite family). */
  accent: string;
  /** Distance label shown on the right, WhatsApp-style. */
  presence: string;
}

export const CONTACTS: Contact[] = [
  {
    id: 'navneet',
    name: 'Navneet',
    status: 'Available',
    initials: 'NV',
    accent: '#00E07A',
    presence: 'online',
  },
  {
    id: 'shreya',
    name: 'Shreya',
    status: 'Living the moment',
    initials: 'SH',
    accent: '#5EEAD4',
    presence: 'last seen today',
  },
  {
    id: 'navya',
    name: 'Navya',
    status: 'Busy',
    initials: 'NA',
    accent: '#A7F3D0',
    presence: 'last seen recently',
  },
  {
    id: 'wons',
    name: 'W.O.N.S',
    status: 'Encrypted circle',
    initials: 'WO',
    accent: '#34D399',
    presence: 'online',
  },
];

export const getContact = (id: string): Contact | undefined =>
  CONTACTS.find((c) => c.id === id);

export const roomIdFor = (contactId: string): string => `room_${contactId}`;
