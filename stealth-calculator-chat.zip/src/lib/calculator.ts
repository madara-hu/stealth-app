/**
 * Pure calculator engine — no UI, no React. Fully testable.
 *
 * Stealth trigger: the user's *key sequence* 7 4 + 8 8 =
 * is detected on the raw key stream (not on the evaluated result),
 * so it fires even though 74 + 88 just equals 162.
 */
import { SECRET_SEQUENCE } from './secret';

export type Operator = '+' | '-' | '×' | '÷';

export interface CalcState {
  /** What the big display shows. */
  display: string;
  /** The frozen left-hand operand while typing the right one. */
  accumulator: number | null;
  /** Pending operator. */
  operator: Operator | null;
  /** True when the next digit starts a fresh entry. */
  replaceEntry: boolean;
  /** Small line above the display, e.g. "74 +". */
  expression: string;
  /** Raw key stream, used only for the stealth trigger. */
  keyStream: string[];
  /** Set when the last action was a division by zero, etc. */
  error: string | null;
}

export const initialState: CalcState = {
  display: '0',
  accumulator: null,
  operator: null,
  replaceEntry: true,
  expression: '',
  keyStream: [],
  error: null,
};

const MAX_DIGITS = 12;

/** Formats a number for a calculator display: max 12 significant chars, no float noise. */
export const formatNumber = (n: number): string => {
  if (!Number.isFinite(n)) return 'Error';
  if (Number.isInteger(n) && Math.abs(n) < 1e12) return String(n);
  const abs = Math.abs(n);
  if (abs !== 0 && (abs >= 1e12 || abs < 1e-9)) {
    return n.toExponential(6).replace(/e([+-])(\d)$/, 'e$10$2');
  }
  const rounded = Number(n.toPrecision(12));
  return String(rounded);
};

export const apply = (a: number, b: number, op: Operator): number => {
  switch (op) {
    case '+':
      return a + b;
    case '-':
      return a - b;
    case '×':
      return a * b;
    case '÷':
      return b === 0 ? NaN : a / b;
  }
};

const KEY_CHARS: Record<string, string> = {
  '+': '+',
  '-': '-',
  '×': '*',
  '÷': '/',
};

/**
 * Reduces the calculator with one key press.
 * `onSecret` fires the moment the stealth sequence completes.
 */
export const pressKey = (
  state: CalcState,
  key: string,
  onSecret: () => void
): CalcState => {
  // ---- stealth trigger: track the raw keystream ----------------------------
  const nextStream = [...state.keyStream, KEY_CHARS[key] ?? key].slice(
    -SECRET_SEQUENCE.length
  );
  const triggered =
    nextStream.length === SECRET_SEQUENCE.length &&
    nextStream.every((k, i) => k === SECRET_SEQUENCE[i]);

  if (triggered) {
    // Reset silently so the calculator is pristine when the user comes back.
    onSecret();
    return { ...initialState };
  }

  const base: CalcState = { ...state, keyStream: nextStream, error: null };

  // ---- digits --------------------------------------------------------------
  if (/^[0-9]$/.test(key)) {
    if (base.replaceEntry || base.display === '0') {
      return { ...base, display: key, replaceEntry: false };
    }
    if (base.display.replace(/[-.]/g, '').length >= MAX_DIGITS) return base;
    return { ...base, display: base.display + key };
  }

  // ---- decimal -------------------------------------------------------------
  if (key === '.') {
    if (base.replaceEntry) return { ...base, display: '0.', replaceEntry: false };
    if (base.display.includes('.')) return base;
    return { ...base, display: base.display + '.' };
  }

  // ---- operators -----------------------------------------------------------
  if (key === '+' || key === '-' || key === '×' || key === '÷') {
    const current = Number(base.display);
    // Chaining: 74 + 88 + → evaluate 162 first.
    if (base.operator !== null && base.accumulator !== null && !base.replaceEntry) {
      const result = apply(base.accumulator, current, base.operator);
      const text = formatNumber(result);
      return {
        ...base,
        display: text,
        accumulator: Number.isFinite(result) ? result : null,
        operator: key,
        replaceEntry: true,
        expression: `${text} ${key}`,
        error: Number.isFinite(result) ? null : 'Cannot divide by zero',
      };
    }
    return {
      ...base,
      accumulator: current,
      operator: key,
      replaceEntry: true,
      expression: `${formatNumber(current)} ${key}`,
    };
  }

  // ---- equals --------------------------------------------------------------
  if (key === '=') {
    if (base.operator === null || base.accumulator === null) {
      return { ...base, expression: `${base.display} =` };
    }
    const result = apply(base.accumulator, Number(base.display), base.operator);
    if (!Number.isFinite(result)) {
      return {
        ...initialState,
        display: 'Error',
        error: 'Cannot divide by zero',
      };
    }
    return {
      ...base,
      display: formatNumber(result),
      accumulator: null,
      operator: null,
      replaceEntry: true,
      expression: `${formatNumber(base.accumulator)} ${
        base.operator
      } ${formatNumber(Number(base.display))} =`,
    };
  }

  // ---- clear ---------------------------------------------------------------
  if (key === 'AC' || key === 'C') {
    return { ...initialState };
  }

  // ---- sign / percent ------------------------------------------------------
  if (key === '+/-') {
    if (base.display === '0' || base.display === 'Error') return base;
    return {
      ...base,
      display: base.display.startsWith('-')
        ? base.display.slice(1)
        : `-${base.display}`,
    };
  }

  if (key === '%') {
    const value = Number(base.display) / 100;
    return { ...base, display: formatNumber(value), replaceEntry: true };
  }

  // ---- backspace -----------------------------------------------------------
  if (key === '⌫') {
    if (base.replaceEntry) return { ...base, display: '0' };
    const next = base.display.slice(0, -1);
    return {
      ...base,
      display: next === '' || next === '-' ? '0' : next,
      replaceEntry: next === '' || next === '-',
    };
  }

  return base;
};
