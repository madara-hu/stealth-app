/**
 * Messaging layer.
 *
 * Real-time Firestore model (deliberately flat, cheap, and indexed):
 *
 *   rooms/{roomId}                     → { contactId, name, lastMessage, lastMessageAt, lastSender }
 *   rooms/{roomId}/messages/{messageId} → { text, senderId, senderName, createdAt, clientId }
 *
 * - `createdAt` is a server timestamp, ordered by Firestore (never client clock).
 * - `senderId` is the anonymous auth uid, so "outgoing" is simply
 *   `message.senderId === auth().currentUser?.uid`.
 *
 * If Firebase is not configured yet, every function falls back to an in-memory
 * store + local echo, so the whole vault is clickable in a dev build / Expo Go.
 */
import { useEffect, useMemo, useRef, useState } from 'react';
import type { FirebaseFirestoreTypes } from '@react-native-firebase/firestore';
import { auth, db, firestore, isFirebaseConfigured, serverTimestamp } from './firebase';
import { CONTACTS, roomIdFor } from './contacts';
import type { Contact } from './contacts';

export interface ChatMessage {
  id: string;
  text: string;
  senderId: string;
  senderName: string;
  createdAt: number | null; // millis, null while the server timestamp resolves
  pending?: boolean;
  failed?: boolean;
}

export interface RoomSummary {
  contactId: string;
  lastMessage: string;
  lastMessageAt: number | null;
  lastSenderId: string | null;
}

type Unsubscribe = () => void;

/* ------------------------------------------------------------------------- */
/* Offline fallback store (used only when Firebase is not configured yet)     */
/* ------------------------------------------------------------------------- */
const memoryMessages: Record<string, ChatMessage[]> = {};
const memoryListeners = new Set<() => void>();

const emitMemory = () => memoryListeners.forEach((fn) => fn());

const seedMessage = (contact: Contact): ChatMessage => ({
  id: `${contact.id}_seed`,
  text:
    contact.id === 'wons'
      ? 'Vault initialised. This room is end-to-end private.'
      : `This is the private line to ${contact.name}. Messages stay in the vault.`,
  senderId: 'system',
  senderName: contact.name,
  createdAt: Date.now() - 1000 * 60 * 60 * 5,
});

const memoryFor = (contactId: string): ChatMessage[] => {
  if (!memoryMessages[contactId]) {
    const contact = CONTACTS.find((c) => c.id === contactId);
    memoryMessages[contactId] = contact ? [seedMessage(contact)] : [];
  }
  return memoryMessages[contactId];
};

/* ------------------------------------------------------------------------- */
/* Seeding rooms once per session                                             */
/* ------------------------------------------------------------------------- */
let seeded = false;

export const seedRooms = async (): Promise<void> => {
  if (seeded || !isFirebaseConfigured()) {
    seeded = true;
    return;
  }
  seeded = true;
  try {
    const batch = db().batch();
    CONTACTS.forEach((contact) => {
      const ref = db().collection('rooms').doc(roomIdFor(contact.id));
      batch.set(
        ref,
        {
          contactId: contact.id,
          name: contact.name,
          members: [auth().currentUser?.uid ?? 'anonymous'],
        },
        { merge: true }
      );
    });
    await batch.commit();
  } catch (error) {
    // Non-fatal: the room is created lazily on first message anyway.
    if (__DEV__) console.warn('[seedRooms] skipped:', error);
  }
};

/* ------------------------------------------------------------------------- */
/* Subscribe to one room's messages                                           */
/* ------------------------------------------------------------------------- */
export const subscribeToMessages = (
  contactId: string,
  onData: (messages: ChatMessage[]) => void,
  onError?: (error: Error) => void
): Unsubscribe => {
  if (!isFirebaseConfigured()) {
    const read = () => onData([...memoryFor(contactId)].sort(sortByTime));
    read();
    memoryListeners.add(read);
    return () => {
      memoryListeners.delete(read);
    };
  }

  const query = db()
    .collection('rooms')
    .doc(roomIdFor(contactId))
    .collection('messages')
    .orderBy('createdAt', 'asc')
    .limitToLast(200);

  return query.onSnapshot(
    (snapshot: FirebaseFirestoreTypes.QuerySnapshot) => {
      const messages: ChatMessage[] = snapshot.docs.map((doc) => {
        const data = doc.data() as {
          text?: string;
          senderId?: string;
          senderName?: string;
          createdAt?: FirebaseFirestoreTypes.Timestamp | null;
        };
        return {
          id: doc.id,
          text: data.text ?? '',
          senderId: data.senderId ?? 'unknown',
          senderName: data.senderName ?? 'Unknown',
          createdAt: data.createdAt ? data.createdAt.toMillis() : null,
        };
      });
      onData(messages);
    },
    (error: Error) => {
      if (__DEV__) console.warn('[subscribeToMessages]', error);
      onError?.(error);
    }
  );
};

/* ------------------------------------------------------------------------- */
/* Send a message                                                             */
/* ------------------------------------------------------------------------- */
export const sendMessage = async (
  contact: Contact,
  rawText: string
): Promise<void> => {
  const text = rawText.trim();
  if (!text) return;

  const user = auth().currentUser;
  const senderId = user?.uid ?? 'local-user';
  const senderName = user?.displayName ?? 'You';

  if (!isFirebaseConfigured()) {
    memoryFor(contact.id).push({
      id: `local_${Date.now()}`,
      text,
      senderId,
      senderName,
      createdAt: Date.now(),
    });
    emitMemory();
    return;
  }

  const roomRef = db().collection('rooms').doc(roomIdFor(contact.id));
  const messageRef = roomRef.collection('messages').doc();

  // Firestore batches are atomic: message + room preview always agree.
  const batch = db().batch();
  batch.set(messageRef, {
    text,
    senderId,
    senderName,
    createdAt: serverTimestamp(),
    clientId: `${senderId}_${Date.now()}`,
  });
  batch.set(
    roomRef,
    {
      contactId: contact.id,
      name: contact.name,
      lastMessage: text,
      lastMessageAt: serverTimestamp(),
      lastSenderId: senderId,
      members: firestore.FieldValue.arrayUnion(senderId),
    },
    { merge: true }
  );
  await batch.commit();
};

/* ------------------------------------------------------------------------- */
/* Room previews for the chat list                                            */
/* ------------------------------------------------------------------------- */
export const subscribeToRooms = (
  onData: (rooms: Record<string, RoomSummary>) => void
): Unsubscribe => {
  if (!isFirebaseConfigured()) {
    const read = () => {
      const result: Record<string, RoomSummary> = {};
      CONTACTS.forEach((contact) => {
        const msgs = memoryMessages[contact.id] ?? [];
        const last = msgs[msgs.length - 1];
        result[contact.id] = {
          contactId: contact.id,
          lastMessage: last?.text ?? contact.status,
          lastMessageAt: last?.createdAt ?? null,
          lastSenderId: last?.senderId ?? null,
        };
      });
      onData(result);
    };
    read();
    memoryListeners.add(read);
    return () => {
      memoryListeners.delete(read);
    };
  }

  return db()
    .collection('rooms')
    .onSnapshot((snapshot: FirebaseFirestoreTypes.QuerySnapshot) => {
      const result: Record<string, RoomSummary> = {};
      snapshot.docs.forEach((doc) => {
        const data = doc.data() as {
          contactId?: string;
          lastMessage?: string;
          lastMessageAt?: FirebaseFirestoreTypes.Timestamp | null;
          lastSenderId?: string | null;
        };
        if (!data.contactId) return;
        result[data.contactId] = {
          contactId: data.contactId,
          lastMessage: data.lastMessage ?? '',
          lastMessageAt: data.lastMessageAt ? data.lastMessageAt.toMillis() : null,
          lastSenderId: data.lastSenderId ?? null,
        };
      });
      onData(result);
    });
};

/* ------------------------------------------------------------------------- */
/* React hooks                                                                */
/* ------------------------------------------------------------------------- */
const sortByTime = (a: ChatMessage, b: ChatMessage) =>
  (a.createdAt ?? Number.MAX_SAFE_INTEGER) - (b.createdAt ?? Number.MAX_SAFE_INTEGER);

export const useMessages = (contactId: string) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState<boolean>(isFirebaseConfigured());

  useEffect(() => {
    setError(null);
    setLoading(isFirebaseConfigured());
    const unsubscribe = subscribeToMessages(
      contactId,
      (next) => {
        setMessages(next);
        setLoading(false);
      },
      (err) => {
        setError(err.message);
        setLoading(false);
      }
    );
    return unsubscribe;
  }, [contactId]);

  const myUid = auth().currentUser?.uid ?? 'local-user';

  return { messages, loading, error, myUid };
};

export const useRoomSummaries = () => {
  const [rooms, setRooms] = useState<Record<string, RoomSummary>>({});
  const settled = useRef(false);

  useEffect(() => {
    const unsubscribe = subscribeToRooms((next) => {
      settled.current = true;
      setRooms(next);
    });
    return unsubscribe;
  }, []);

  return useMemo(() => rooms, [rooms]);
};
