/**
 * firebase.ts — single place where Firebase is initialised.
 *
 * ⚠️  NO KEYS ARE HARDCODED HERE.
 * Native Firebase config comes from:
 *   • Android → ./google-services.json  (you drop this in)
 *   • iOS     → ./GoogleService-Info.plist (you drop this in)
 * Both files are referenced from app.json, so @react-native-firebase/app
 * picks the config up natively at build time. Nothing secret belongs in JS.
 *
 * If you *do* want web/JS-only config later, put it in `.env` and reference it
 * through app.json → `extra`, then read it with expo-constants.
 */
import firebase from '@react-native-firebase/app';
import auth, { type FirebaseAuthTypes } from '@react-native-firebase/auth';
import firestore, { type FirebaseFirestoreTypes } from '@react-native-firebase/firestore';

/** True when the native Firebase app was configured (i.e. google-services.json was present). */
export const isFirebaseConfigured = (): boolean => {
  try {
    return firebase.apps.length > 0;
  } catch {
    return false;
  }
};

/**
 * Anonymous sign-in, idempotent. Call once at app start.
 * Returns the signed-in user, or `null` when Firebase is not configured
 * (so the app can show a friendly banner instead of crashing).
 */
export const ensureAnonymousSession = async (): Promise<FirebaseAuthTypes.User | null> => {
  if (!isFirebaseConfigured()) {
    return null;
  }
  const current = auth().currentUser;
  if (current) return current;
  const cred = await auth().signInAnonymously();
  return cred.user;
};

/** Firestore handle (throws a readable error if config is missing). */
export const db = () => {
  if (!isFirebaseConfigured()) {
    throw new Error(
      'Firebase is not configured. Add google-services.json (Android) / GoogleService-Info.plist (iOS) and rebuild.'
    );
  }
  return firestore();
};

export const serverTimestamp = () => firestore.FieldValue.serverTimestamp();

export type { FirebaseAuthTypes, FirebaseFirestoreTypes };
export { firebase, auth, firestore };
export default firebase;
