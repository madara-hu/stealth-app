/**
 * The stealth contract, kept in one tiny file so it's easy to change.
 *
 * The user's trigger sequence is:  7  4  +  8  8  =
 * It is matched against the RAW KEY STREAM (the keys the user actually taps),
 * never against the computed result — 74 + 88 = 162 would never match "7488".
 *
 * `keys` uses calculator-glyph names; `*` / `/` are the mapped equivalents so
 * the pattern still matches if you later wire a hardware keyboard.
 */
export const SECRET_SEQUENCE: string[] = ['7', '4', '+', '8', '8', '='];

/** Human-readable version, shown only in the README / dev builds. */
export const SECRET_SEQUENCE_LABEL = SECRET_SEQUENCE.join(' ');
