/**
 * Icons — hand-drawn with react-native-svg so there is no icon-font
 * build step, no asset linking, and no version drift on EAS.
 */
import React from 'react';
import Svg, { Circle, Path, Rect } from 'react-native-svg';

export interface IconProps {
  size?: number;
  color?: string;
  strokeWidth?: number;
}

const base = (size: number) => ({ width: size, height: size, viewBox: '0 0 24 24' });

export const SearchIcon: React.FC<IconProps> = ({
  size = 18,
  color = '#8A8A95',
  strokeWidth = 1.9,
}) => (
  <Svg {...base(size)} fill="none">
    <Circle cx={11} cy={11} r={6.5} stroke={color} strokeWidth={strokeWidth} />
    <Path
      d="M16 16l4.2 4.2"
      stroke={color}
      strokeWidth={strokeWidth}
      strokeLinecap="round"
    />
  </Svg>
);

export const MoreIcon: React.FC<IconProps> = ({
  size = 20,
  color = '#8A8A95',
  strokeWidth = 2,
}) => (
  <Svg {...base(size)} fill="none">
    <Circle cx={12} cy={5} r={1.6} fill={color} />
    <Circle cx={12} cy={12} r={1.6} fill={color} />
    <Circle cx={12} cy={19} r={1.6} fill={color} />
    <Rect x={0} y={0} width={0} height={0} stroke={color} strokeWidth={strokeWidth} />
  </Svg>
);

export const LockIcon: React.FC<IconProps> = ({
  size = 18,
  color = '#00E07A',
  strokeWidth = 1.9,
}) => (
  <Svg {...base(size)} fill="none">
    <Rect
      x={4.5}
      y={10.2}
      width={15}
      height={10.3}
      rx={2.6}
      stroke={color}
      strokeWidth={strokeWidth}
    />
    <Path
      d="M8.2 10.2V7.6a3.8 3.8 0 017.6 0v2.6"
      stroke={color}
      strokeWidth={strokeWidth}
      strokeLinecap="round"
    />
    <Circle cx={12} cy={15.3} r={1.45} fill={color} />
  </Svg>
);

export const BackIcon: React.FC<IconProps> = ({
  size = 22,
  color = '#F2F2F4',
  strokeWidth = 2.1,
}) => (
  <Svg {...base(size)} fill="none">
    <Path
      d="M14.5 5L8 12l6.5 7"
      stroke={color}
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </Svg>
);

export const SendIcon: React.FC<IconProps> = ({
  size = 20,
  color = '#001B0E',
  strokeWidth = 1.9,
}) => (
  <Svg {...base(size)} fill="none">
    <Path
      d="M4 12l16-7-6.6 16-2.4-6.6L4 12z"
      fill={color}
      stroke={color}
      strokeWidth={strokeWidth * 0.5}
      strokeLinejoin="round"
    />
  </Svg>
);

export const PhoneIcon: React.FC<IconProps> = ({
  size = 19,
  color = '#00E07A',
  strokeWidth = 1.9,
}) => (
  <Svg {...base(size)} fill="none">
    <Path
      d="M6.2 3.8l2.1-.9 1.7 3.7-1.6 1.3a11.4 11.4 0 006.9 6.9l1.3-1.6 3.7 1.7-.9 2.1a2.3 2.3 0 01-2.6 1.4C10.4 19 5 13.6 3.8 6.4A2.3 2.3 0 016.2 3.8z"
      stroke={color}
      strokeWidth={strokeWidth}
      strokeLinejoin="round"
    />
  </Svg>
);

export const VideoIcon: React.FC<IconProps> = ({
  size = 20,
  color = '#00E07A',
  strokeWidth = 1.9,
}) => (
  <Svg {...base(size)} fill="none">
    <Rect x={2.8} y={6} width={12} height={12} rx={3} stroke={color} strokeWidth={strokeWidth} />
    <Path
      d="M14.8 11l5-3.2v8.4l-5-3.2z"
      stroke={color}
      strokeWidth={strokeWidth}
      strokeLinejoin="round"
    />
  </Svg>
);

export const CheckIcon: React.FC<IconProps> = ({
  size = 14,
  color = '#00E07A',
  strokeWidth = 2.2,
}) => (
  <Svg {...base(size)} fill="none">
    <Path
      d="M4 12.8l4.4 4.2L20 5.6"
      stroke={color}
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </Svg>
);

export const KeypadIcon: React.FC<IconProps> = ({ size = 20, color = '#8A8A95' }) => (
  <Svg {...base(size)} fill="none">
    {[5, 12, 19].map((cy) =>
      [5, 12, 19].map((cx) => <Circle key={`${cx}-${cy}`} cx={cx} cy={cy} r={1.5} fill={color} />)
    )}
    <Circle cx={0} cy={0} r={0} stroke={color} strokeWidth={0} />
  </Svg>
);

export const ShieldIcon: React.FC<IconProps> = ({
  size = 16,
  color = '#00E07A',
  strokeWidth = 1.9,
}) => (
  <Svg {...base(size)} fill="none">
    <Path
      d="M12 3l7 3v6c0 4.2-2.9 7.6-7 9-4.1-1.4-7-4.8-7-9V6l7-3z"
      stroke={color}
      strokeWidth={strokeWidth}
      strokeLinejoin="round"
    />
    <Path
      d="M8.8 12.1l2.2 2.2 4.2-4.2"
      stroke={color}
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </Svg>
);

export const ChevronIcon: React.FC<IconProps> = ({
  size = 18,
  color = '#6A6A75',
  strokeWidth = 2,
}) => (
  <Svg {...base(size)} fill="none">
    <Path
      d="M9.5 5.5L16 12l-6.5 6.5"
      stroke={color}
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </Svg>
);
