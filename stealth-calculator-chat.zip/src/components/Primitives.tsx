/**
 * Shared premium UI atoms.
 */
import React, { useRef } from 'react';
import {
  Animated,
  Pressable,
  StyleSheet,
  Text,
  View,
  type StyleProp,
  type ViewStyle,
} from 'react-native';
import Svg, { Defs, LinearGradient, Rect, Stop } from 'react-native-svg';
import { palette, radius } from '../theme';

/* -------------------------------------------------------------------------- */
/* Calculator key                                                              */
/* -------------------------------------------------------------------------- */
export type KeyVariant = 'digit' | 'fn' | 'operator' | 'equals';

interface CalcKeyProps {
  label: string;
  variant?: KeyVariant;
  onPress: (key: string) => void;
  wide?: boolean;
}

const KEY_BG: Record<KeyVariant, string> = {
  digit: palette.calcOp,
  fn: palette.calcFn,
  operator: palette.calcOp,
  equals: palette.calcEquals,
};

const KEY_FG: Record<KeyVariant, string> = {
  digit: palette.calcFnText,
  fn: palette.calcFnText,
  operator: palette.calcOpText,
  equals: palette.calcEqualsText,
};

export const CalcKey: React.FC<CalcKeyProps> = ({
  label,
  variant = 'digit',
  onPress,
  wide = false,
}) => {
  const scale = useRef(new Animated.Value(1)).current;

  const spring = (toValue: number) =>
    Animated.spring(scale, {
      toValue,
      useNativeDriver: true,
      speed: 40,
      bounciness: 0,
    }).start();

  return (
    <View style={[styles.keyWrap, wide && styles.keyWideWrap]}>
      <Animated.View
        style={[
          styles.keyFlex,
          { transform: [{ scale }] },
          variant === 'equals' && styles.keyEqualsGlow,
        ]}
      >
        <Pressable
          accessibilityRole="button"
          accessibilityLabel={label}
          onPressIn={() => spring(0.94)}
          onPressOut={() => spring(1)}
          onPress={() => onPress(label)}
          android_ripple={{ color: 'rgba(255,255,255,0.10)', borderless: true }}
          style={[
            styles.key,
            wide && styles.keyWide,
            { backgroundColor: KEY_BG[variant] },
          ]}
        >
          <Text
            style={[
              styles.keyLabel,
              { color: KEY_FG[variant] },
              variant === 'operator' && styles.keyLabelOperator,
              label.length > 2 && styles.keyLabelSmall,
            ]}
            numberOfLines={1}
          >
            {label}
          </Text>
        </Pressable>
      </Animated.View>
    </View>
  );
};

/* -------------------------------------------------------------------------- */
/* Avatar                                                                      */
/* -------------------------------------------------------------------------- */
interface AvatarProps {
  initials: string;
  accent: string;
  size?: number;
  online?: boolean;
}

export const Avatar: React.FC<AvatarProps> = ({
  initials,
  accent,
  size = 52,
  online = false,
}) => (
  <View style={{ width: size, height: size }}>
    <View
      style={[
        styles.avatar,
        {
          width: size,
          height: size,
          borderRadius: radius.pill,
          borderColor: `${accent}44`,
        },
      ]}
    >
      <Text
        style={[
          styles.avatarText,
          { color: accent, fontSize: size * 0.33, letterSpacing: size * 0.02 },
        ]}
      >
        {initials}
      </Text>
    </View>
    {online ? (
      <View
        style={[
          styles.presence,
          {
            borderColor: palette.ink,
            width: size * 0.26,
            height: size * 0.26,
            borderRadius: size * 0.13,
          },
        ]}
      />
    ) : null}
  </View>
);

/* -------------------------------------------------------------------------- */
/* Emerald hairline / gradient surface                                         */
/* -------------------------------------------------------------------------- */
export const NeonGradient: React.FC<{
  style?: StyleProp<ViewStyle>;
  opacity?: number;
}> = ({ style, opacity = 0.5 }) => (
  <View pointerEvents="none" style={[StyleSheet.absoluteFillObject, style]}>
    <Svg width="100%" height="100%">
      <Defs>
        <LinearGradient id="neon" x1="0" y1="0" x2="1" y2="1">
          <Stop offset="0" stopColor={palette.emerald} stopOpacity={opacity} />
          <Stop offset="0.5" stopColor={palette.emeraldDeep} stopOpacity={opacity * 0.25} />
          <Stop offset="1" stopColor={palette.emerald} stopOpacity={opacity} />
        </LinearGradient>
      </Defs>
      <Rect x="0" y="0" width="100%" height="100%" fill="url(#neon)" />
    </Svg>
  </View>
);

/* -------------------------------------------------------------------------- */
/* Styles                                                                      */
/* -------------------------------------------------------------------------- */
export const styles = StyleSheet.create({
  keyWrap: {
    flex: 1,
    aspectRatio: 1,
    padding: 5,
  },
  keyWideWrap: {
    flex: 2.08,
    aspectRatio: undefined,
  },
  keyFlex: {
    flex: 1,
  },
  keyEqualsGlow: {
    shadowColor: palette.emerald,
    shadowOpacity: 0.6,
    shadowRadius: 18,
    shadowOffset: { width: 0, height: 0 },
    elevation: 12,
  },
  key: {
    flex: 1,
    borderRadius: radius.pill,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: palette.hairline,
  },
  keyWide: {
    borderRadius: radius.pill,
    alignItems: 'flex-start',
    paddingLeft: 28,
  },
  keyLabel: {
    fontSize: 27,
    fontWeight: '400',
  },
  keyLabelOperator: {
    fontSize: 30,
    fontWeight: '500',
  },
  keyLabelSmall: {
    fontSize: 19,
    fontWeight: '600',
  },
  avatar: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: palette.surfaceRaised,
    borderWidth: 1,
  },
  avatarText: {
    fontWeight: '700',
  },
  presence: {
    position: 'absolute',
    right: 0,
    bottom: 0,
    backgroundColor: palette.emerald,
    borderWidth: 2.5,
  },
});
